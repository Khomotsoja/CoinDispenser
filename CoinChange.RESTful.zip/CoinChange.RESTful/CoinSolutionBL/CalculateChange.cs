﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoinSolutionBL
{
  public  class CalculateChange
    {
     public int MinimumCoins(int[] coins, int m, int v)
        {

            //int[] coins - Different coins 
            //m - the length of the coins array
            //V - the amount that needs change

            // Check if a valid amount has been entered
            if (v == 0)
            {
                return 0;
            }


            // variable that will the store results
            int result = int.MaxValue;

            //Making sure that every coin is less than V
            for (int i = 0; i < m; i++)
            {
                if (coins[i] <= v)
                {
                    int sub_res = MinimumCoins(coins, m, v - coins[i]);

                    //Check intMax to avoid overflow
                    if (sub_res != int.MaxValue && sub_res + 1 < result)
                    {
                        result = sub_res + 1;
                    }
                }
            }
            return result;
        }
    }

}
