﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CoinChange.RESTful;
using CoinSolutionBL;


namespace CoinChange.RESTful.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            CoinChange.RESTful.CoinChangeService coinChange = new CoinChange.RESTful.CoinChangeService();

            int result = coinChange.ProvideMinChange(new int[] { 7, 3, 2,3 ,} , 6);
            Assert.AreEqual(result, 2);

        }
    }
}
