﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Text;
using CoinSolutionBL;

namespace CoinChange.RESTful
{
    [ServiceContract(Namespace = "")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class CoinChangeService
    {

        private CoinSolutionBL.CalculateChange _bLCoinChangeService;

        public CoinChangeService()
        {
            _bLCoinChangeService = new CoinSolutionBL.CalculateChange();
        }


        [OperationContract]
        [WebGet(UriTemplate= "/ProvideMinChange")]
        public int ProvideMinChange(int[] coins,int v)
        {
            int len = coins.Length;

            return _bLCoinChangeService.MinimumCoins(coins, len, v);

            
        }

       
    }
}
